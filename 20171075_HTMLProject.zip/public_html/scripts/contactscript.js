var x=document.getElementById("contactForm");
function submitfn(){
  x.submit();
}
function resetfn(){
  x.reset();
}
