function disp1(){
	document.getElementById("box1").style.display="block";
	document.getElementById("box2").style.display="none";
	document.getElementById("box3").style.display="none";
	document.getElementById("boxlose").style.display="none";
	document.getElementById("boxwin").style.display="none";
}
function disp2(){
	document.getElementById("box1").style.display="none";
	document.getElementById("box2").style.display="block";
	document.getElementById("box3").style.display="none";
	document.getElementById("boxlose").style.display="none";
	document.getElementById("boxwin").style.display="none";
}
function disp3(){
	document.getElementById("box1").style.display="none";
	document.getElementById("box2").style.display="none";
	document.getElementById("box3").style.display="block";
	document.getElementById("boxlose").style.display="none";
	document.getElementById("boxwin").style.display="none";
}
function displose(){
	document.getElementById("box1").style.display="none";
	document.getElementById("box2").style.display="none";
	document.getElementById("box3").style.display="none";
	document.getElementById("boxlose").style.display="block";
	document.getElementById("boxwin").style.display="none";
}
function dispwin(){
	document.getElementById("box1").style.display="none";
	document.getElementById("box2").style.display="none";
	document.getElementById("box3").style.display="none";
	document.getElementById("boxlose").style.display="none";
	document.getElementById("boxwin").style.display="block";
}
